# Presentación Tri-Fuerza · HelpDesk

Presentación web de 17 diapositivas (HTML, CSS y JS sin dependencias).

- Abrir `index.html` en el navegador (funciona sin internet).
- Navegación: flechas, espacio, deslizar en móvil. `#d5` abre la diapositiva 5.
- Para publicarla en GitHub Pages: subir esta carpeta y activar Pages.
